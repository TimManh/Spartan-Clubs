//
//  ViewController.swift
//  clubCollection
//
//  Created by Carmen  on 5/3/19.
//  Copyright © 2019 Carmen . All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    @IBOutlet weak var collectionView: UICollectionView!
    
    let clubs = ["Academic Scholars","Active Minds", "BRAVEN", "IDEAS", "SJSU Robotics", "SWE", "SCE", "Stem Now"]
    
    let clubImages: [UIImage] = [
    
        UIImage(named: "academicScholars")!,
        UIImage(named: "activeMinds")!,
        UIImage(named: "braven")!,
        UIImage(named: "ideas")!,
        UIImage(named: "robotics")!,
        UIImage(named: "swe")!,
        UIImage(named: "sce")!,
        UIImage(named: "stemNow")!

    ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        collectionView.dataSource = self
        collectionView.delegate = self
        
        var layout = self.collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.sectionInset = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
        layout.minimumInteritemSpacing = 5
        layout.itemSize = CGSize(width:(self.collectionView.frame.size.width - 20)/2, height: self.collectionView.frame.size.height/3)
        
        
        
        
    }
 

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return clubs.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! CollectionViewCell
        
        cell.clubLabel.text = clubs[indexPath.item]
        cell.clubImageView.image = clubImages[indexPath.item]
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.borderWidth = 0.5
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        cell?.layer.borderColor = UIColor.gray.cgColor
        cell?.layer.borderWidth = 2
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        cell?.layer.borderColor = UIColor.lightGray.cgColor
        cell?.layer.borderWidth = 0.5
    }
}

