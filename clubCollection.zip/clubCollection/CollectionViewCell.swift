//
//  CollectionViewCell.swift
//  clubCollection
//
//  Created by Carmen  on 5/3/19.
//  Copyright © 2019 Carmen . All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var clubImageView: UIImageView!
    @IBOutlet weak var clubLabel: UILabel!
}
